package herencia;

public class Vehiculo {
    private int velocidadMax;  //aqui se definen las caracteristicas en comun de los vehiculos
    private int capacidadPasajeros;
    private double peso;
    private String fabricante;
    private String modelo;
    private String tipoCombustible;
    private String color;

    public Vehiculo(int velocidadMax, int capacidadPasajeros, double peso, String fabricante, String modelo, String tipoCombustible, String color) {
        this.velocidadMax = velocidadMax;
        this.capacidadPasajeros = capacidadPasajeros;
        this.peso = peso;
        this.fabricante = fabricante;
        this.modelo = modelo;
        this.tipoCombustible = tipoCombustible;
        this.color = color;
    }

    public int getVelocidadMax() {
        return velocidadMax;
    }

    public void setVelocidadMax(int velocidadMax) {
        this.velocidadMax = velocidadMax;
    }

    public int getCapacidadPasajeros() {
        return capacidadPasajeros;
    }

    public void setCapacidadPasajeros(int capacidadPasajeros) {
        this.capacidadPasajeros = capacidadPasajeros;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getTipoCombustible() {
        return tipoCombustible;
    }

    public void setTipoCombustible(String tipoCombustible) {
        this.tipoCombustible = tipoCombustible;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    
    
}
