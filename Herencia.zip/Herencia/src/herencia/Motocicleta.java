package herencia;

public class Motocicleta extends Vehiculo {
    private int cilindraje;
    private String tipoMoto;
    private String tipoFrenos;

    public Motocicleta(int cilindraje, String tipoMoto, String tipoFrenos, int velocidadMax, int capacidadPasajeros, double peso, String fabricante, String modelo, String tipoCombustible, String color) {
        super(velocidadMax, capacidadPasajeros, peso, fabricante, modelo, tipoCombustible, color);
        this.cilindraje = cilindraje;
        this.tipoMoto = tipoMoto;
        this.tipoFrenos = tipoFrenos;
    }

    public int getCilindraje() {
        return cilindraje;
    }

    public void setCilindraje(int cilindraje) {
        this.cilindraje = cilindraje;
    }

    public String getTipoMoto() {
        return tipoMoto;
    }

    public void setTipoMoto(String tipoMoto) {
        this.tipoMoto = tipoMoto;
    }

    public String getTipoFrenos() {
        return tipoFrenos;
    }

    public void setTipoFrenos(String tipoFrenos) {
        this.tipoFrenos = tipoFrenos;
    }
    
    
    
}
