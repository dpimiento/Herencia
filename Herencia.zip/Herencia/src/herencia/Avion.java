package herencia;

public class Avion extends Vehiculo {
    private String tipoAvion;
    private double capacidadCarga;
    private double envergaduraAlas;

    public Avion(String tipoAvion, double capacidadCarga, double envergaduraAlas, int velocidadMax, int capacidadPasajeros, double peso, String fabricante, String modelo, String tipoCombustible, String color) {
        super(velocidadMax, capacidadPasajeros, peso, fabricante, modelo, tipoCombustible, color);
        this.tipoAvion = tipoAvion;
        this.capacidadCarga = capacidadCarga;
        this.envergaduraAlas = envergaduraAlas;
    }

    public String getTipoAvion() {
        return tipoAvion;
    }

    public void setTipoAvion(String tipoAvion) {
        this.tipoAvion = tipoAvion;
    }

    public double getCapacidadCarga() {
        return capacidadCarga;
    }

    public void setCapacidadCarga(double capacidadCarga) {
        this.capacidadCarga = capacidadCarga;
    }

    public double getEnvergaduraAlas() {
        return envergaduraAlas;
    }

    public void setEnvergaduraAlas(double envergaduraAlas) {
        this.envergaduraAlas = envergaduraAlas;
    }
    
    
    
}
