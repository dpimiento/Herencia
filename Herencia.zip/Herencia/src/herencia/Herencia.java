package herencia;


public class Herencia { //Coche(int numRuedas, int numPuertas, String tipoTransmision, int velocidadMax, int capacidadPasajeros, double peso, 
    //String fabricante, String modelo, String tipoCombustible, String color) {
        

    public static void main(String[] args) {
        // Creación de objetos tipo Coche
        Coche audi = new Coche(4, 4, "Automática", 250, 5, 1500, "Audi", "A4", "Gasolina", "Rojo");
        Coche mazda = new Coche(4, 4, "Manual", 220, 5, 1400, "Mazda", "3", "Gasolina", "Azul");
        Coche renault = new Coche(4, 4, "Automática", 210, 5, 1450, "Renault", "Logan", "Diesel", "Blanco");

        // Creación de objeto tipo Avion
        Avion jet = new Avion("Jet privado", 5000, 25, 850, 20, 50000, "Boeing", "737", "Queroseno", "Blanco");

        // Creación de objetos tipo Motocicleta
        Motocicleta suzuki = new Motocicleta(999, "Deportiva", "Manual", 180, 2, 200, "Suzuki", "GSX-R1000", "Gasolina", "Negro");
        Motocicleta yamaha = new Motocicleta(998, "Deportiva", "Manual", 190, 2, 220, "Yamaha", "YZF-R1", "Gasolina", "Azul");
        Motocicleta honda = new Motocicleta(1833, "Touring", "Automática", 160, 2, 250, "Honda", "Gold Wing", "Gasolina", "Rojo");

        // Creación de objetos tipo Bote
        Bote lancha = new Bote("Lancha rapida", 15, "Motor fuera de borda", 70, 8, 1200, "Yamaha", "FX Cruiser", "Gasolina", "Azul");
        Bote barco = new Bote("Barco de carga", 300, "Motor diesel", 45, 50, 200000, "Maersk", "Triple E", "Diesel", "Gris");
        
        System.out.println("Coche Audi: " + audi.getFabricante() + " " + audi.getModelo() + " con " + audi.getNumRuedas() + " ruedas y " + audi.getNumPuertas() + " puertas.");
        System.out.println("Coche Mazda: " + mazda.getFabricante() + " " + mazda.getModelo() + " con " + mazda.getNumRuedas() + " ruedas y " + mazda.getNumPuertas() + " puertas.");
        System.out.println("Coche Renault: " + renault.getFabricante() + " " + renault.getModelo() + " con " + renault.getNumRuedas() + " ruedas y " + renault.getNumPuertas() + " puertas.");
        System.out.println("Avion Jet: " + jet.getFabricante() + " " + jet.getModelo() + " de tipo " + jet.getTipoAvion() + " con capacidad de carga de " + jet.getCapacidadCarga() + " kg.");
        System.out.println("Motocicleta Suzuki: "+ suzuki.getFabricante()+ " " + suzuki.getModelo() + " de cilindraje " + suzuki.getCilindraje()+" CC, con velocidad maxima de " + suzuki.getVelocidadMax() + "Km/H");
        System.out.println("Motocicleta Yamaha: "+ yamaha.getFabricante()+ " " + yamaha.getModelo() + " de cilindraje " + yamaha.getCilindraje()+" CC, con velocidad maxima de " + yamaha.getVelocidadMax() + "Km/H");
        System.out.println("Motocicleta Honda: "+ honda.getFabricante()+ " " + honda.getModelo() + " de cilindraje " + honda.getCilindraje()+" CC, con velocidad maxima de " + honda.getVelocidadMax()+ "Km/H");
        System.out.println("Barco de carga: " + barco.getFabricante() + " " + barco.getModelo() + " de tipo " + barco.getTipoBote() + " con una longitud de " + barco.getLongitud() + " metros.");
        System.out.println("Bote Lancha: " + lancha.getFabricante() + " " + lancha.getModelo() + " de tipo " + lancha.getTipoBote() + " con una longitud de " + lancha.getLongitud() + " metros.");
    }
    
}
