package herencia;

public class Coche extends Vehiculo{
    private int numRuedas;   
    private int numPuertas;
    private String tipoTransmision;

    public Coche(int numRuedas, int numPuertas, String tipoTransmision, int velocidadMax, int capacidadPasajeros, double peso, String fabricante, String modelo, String tipoCombustible, String color) {
        super(velocidadMax, capacidadPasajeros, peso, fabricante, modelo, tipoCombustible, color);
        this.numRuedas = numRuedas;
        this.numPuertas = numPuertas;
        this.tipoTransmision = tipoTransmision;
    }

    public int getNumRuedas() {
        return numRuedas;
    }

    public void setNumRuedas(int numRuedas) {
        this.numRuedas = numRuedas;
    }

    public int getNumPuertas() {
        return numPuertas;
    }

    public void setNumPuertas(int numPuertas) {
        this.numPuertas = numPuertas;
    }

    public String getTipoTransmision() {
        return tipoTransmision;
    }

    public void setTipoTransmision(String tipoTransmision) {
        this.tipoTransmision = tipoTransmision;
    }
    
}
