package herencia;

public class Bote extends Vehiculo {
    private String tipoBote;
    private double longitud;
    private String tipoPropulsion;

    public Bote(String tipoBote, double longitud, String tipoPropulsion, int velocidadMax, int capacidadPasajeros, double peso, String fabricante, String modelo, String tipoCombustible, String color) {
        super(velocidadMax, capacidadPasajeros, peso, fabricante, modelo, tipoCombustible, color);
        this.tipoBote = tipoBote;
        this.longitud = longitud;
        this.tipoPropulsion = tipoPropulsion;
    }

    public String getTipoBote() {
        return tipoBote;
    }

    public void setTipoBote(String tipoBote) {
        this.tipoBote = tipoBote;
    }

    public double getLongitud() {
        return longitud;
    }

    public void setLongitud(double longitud) {
        this.longitud = longitud;
    }

    public String getTipoPropulsion() {
        return tipoPropulsion;
    }

    public void setTipoPropulsion(String tipoPropulsion) {
        this.tipoPropulsion = tipoPropulsion;
    }
    
    
}
